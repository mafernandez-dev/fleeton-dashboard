// =========================================
// STATE & CONFIGURATION
// =========================================
const PLANS = {
    free: { id: 'free', name: 'Free', price: 0, limits: { units: 5, drivers: 5, alerts: 'basic' } },
    pro: { id: 'pro', name: 'Pro', price: 29, limits: { units: 25, drivers: 10, alerts: 'advanced' } },
    enterprise: { id: 'enterprise', name: 'Enterprise', price: 99, limits: { units: Infinity, drivers: Infinity, alerts: 'advanced' } }
};

const DefaultState = {
    user: { name: 'Carlos', email: 'carlos@fleet.com', role: 'Administrador', avatar_url: '', plan: 'free' },
    fleet: [
        { id: 'u-001', unit_name: 'Volvo FH16 - 45T', driver: 'M. Torres', status: 'active', plate: 'ABC-123', year: 2022, mileage: 145000, status_comment: '', maintenance_info: null, insurance_expiry: '2025-02-15', next_maintenance_km: 150000, next_maintenance_date: '2025-03-01' },
        { id: 'u-002', unit_name: 'Scania R500', driver: 'J. Gómez', status: 'active', plate: 'DEF-456', year: 2021, mileage: 178000, status_comment: '', maintenance_info: null, insurance_expiry: '2025-06-20', next_maintenance_km: 180000, next_maintenance_date: '2025-04-15' },
        { id: 'u-003', unit_name: 'Mercedes Actros', driver: 'Sin asignar', status: 'maintenance', plate: 'GHI-789', year: 2020, mileage: 210000, status_comment: 'Falla en transmisión', maintenance_info: { entry_date: '2025-01-15', issue: 'Falla en caja de cambios', parts_needed: 'Caja de cambios completa, embrague', mechanic: 'Taller Central S.A.', estimated_exit: '2025-02-01' }, insurance_expiry: '2025-01-30', next_maintenance_km: 215000, next_maintenance_date: '2025-02-10' },
        { id: 'u-004', unit_name: 'DAF XF', driver: 'L. Ruiz', status: 'idle', plate: 'JKL-012', year: 2023, mileage: 89000, status_comment: 'Esperando asignación de ruta', maintenance_info: null, insurance_expiry: '2025-12-01', next_maintenance_km: 100000, next_maintenance_date: '2025-05-01' },
        { id: 'u-005', unit_name: 'MAN TGX', driver: 'P. Silva', status: 'active', plate: 'MNO-345', year: 2022, mileage: 132000, status_comment: '', maintenance_info: null, insurance_expiry: '2025-08-15', next_maintenance_km: 140000, next_maintenance_date: '2025-03-20' }
    ],
    drivers: [
        { id: 'd-001', name: 'M. Torres', phone: '+52 555 123 4567', license: 'A-12345' },
        { id: 'd-002', name: 'J. Gómez', phone: '+52 555 234 5678', license: 'A-23456' },
        { id: 'd-003', name: 'L. Ruiz', phone: '+52 555 345 6789', license: 'A-34567' },
        { id: 'd-004', name: 'P. Silva', phone: '+52 555 456 7890', license: 'A-45678' }
    ],
    alerts: [
        { id: 'a-001', unit_id: 'u-003', title: 'Mantenimiento Vencido', desc: 'Mercedes Actros - Cambio de aceite', severity: 'critical', resolved: false },
        { id: 'a-002', unit_id: 'u-001', title: 'Seguro por vencer', desc: 'Volvo FH16 - Vence en 3 días', severity: 'warning', resolved: false },
        { id: 'a-003', unit_id: 'u-002', title: 'Revisión técnica', desc: 'Scania R500 - Programada para mañana', severity: 'warning', resolved: false }
    ],
    activityLog: [],
    filters: { fleet: { status: 'all', search: '' }, alerts: { severity: 'all' }, drivers: { search: '' }, activity: { type: 'all' } },
    preferences: { notifications: true, darkMode: false },
    listeners: [],
    isLoading: false
};

let State = JSON.parse(JSON.stringify(DefaultState));

// =========================================
// DOM REFERENCES
// =========================================
const DOM = {
    fleetContainer: document.getElementById('fleet-container'),
    alertsContainer: document.getElementById('alerts-container'),
    upcomingContainer: document.getElementById('upcoming-container'),
    upcomingFullContainer: document.getElementById('upcoming-full-container'),
    activityContainer: document.getElementById('activity-container'),
    activityFullContainer: document.getElementById('activity-full-container'),
    metricActive: document.getElementById('metric-active'),
    metricMaintenance: document.getElementById('metric-maintenance'),
    metricIdle: document.getElementById('metric-idle'),
    metricAlerts: document.getElementById('metric-alerts'),
    fleetFullContainer: document.getElementById('fleet-full-container'),
    fleetSearch: document.getElementById('fleet-search'),
    alertsFullContainer: document.getElementById('alerts-full-container'),
    driversContainer: document.getElementById('drivers-container'),
    driverSearch: document.getElementById('driver-search'),
    navItems: document.querySelectorAll('.nav-item'),
    views: document.querySelectorAll('.view'),
    sheetOverlay: document.getElementById('sheet-overlay'),
    bottomSheet: document.getElementById('bottom-sheet'),
    sheetContent: document.getElementById('sheet-content'),
    modalOverlay: document.getElementById('modal-overlay'),
    modal: document.getElementById('modal'),
    modalTitle: document.getElementById('modal-title'),
    modalBody: document.getElementById('modal-body'),
    modalFooter: document.getElementById('modal-footer'),
    toastContainer: document.getElementById('toast-container')
};

// =========================================
// UTILITIES
// =========================================
function sanitizeHTML(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// Sanitización estricta para atributos HTML (data-id, data-action, etc.)
function strictSanitize(str) {
    if (!str) return '';
    return str.replace(/[<>"'&]/g, (char) => ({
        '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;', '&': '&amp;'
    }[char]));
}

// Para descripciones de actividad (permite <strong>)
function sanitizeActivityDescription(str) {
    if (!str) return '';
    return str.replace(/<(?!\/?strong\b)[^>]*>/gi, '');
}

// Validación de URLs
function isValidImageUrl(url) {
    if (!url) return false;
    try {
        const parsed = new URL(url);
        return ['http:', 'https:'].includes(parsed.protocol);
    } catch {
        return false;
    }
}

// Parseo seguro de enteros
function safeParseInt(value, min, max) {
    const num = parseInt(value, 10);
    if (isNaN(num) || num < min || num > max) return null;
    return num;
}

function getStatusLabel(status) {
    const labels = { active: 'Activa', maintenance: 'Taller', idle: 'Inactiva' };
    return labels[status] || status;
}

function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'toast';
    toast.textContent = sanitizeHTML(message);
    DOM.toastContainer.appendChild(toast);
    setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 200); }, 3000);
}

function formatDate(dateString) {
    if (!dateString) return 'No definida';
    return new Date(dateString).toLocaleDateString('es-ES', { year: 'numeric', month: 'long', day: 'numeric' });
}

function getLimitStatus(current, limit) {
    if (limit === Infinity) return { text: `${current}/∞`, class: '' };
    const percentage = (current / limit) * 100;
    let className = percentage >= 90 ? 'critical' : (percentage >= 75 ? 'warning' : '');
    return { text: `${current}/${limit}`, class: className };
}

function checkUnitLimit() {
    const limit = PLANS[State.user.plan].limits.units;
    if (State.fleet.length >= limit) { showToast(`Límite alcanzado: ${limit} unidades`); return false; }
    return true;
}

function checkDriverLimit() {
    const limit = PLANS[State.user.plan].limits.drivers;
    if (State.drivers.length >= limit) { showToast(`Límite alcanzado: ${limit} conductores`); return false; }
    return true;
}

// =========================================
// ACTIVITY LOG SYSTEM
// =========================================
function logActivity(type, entity, entityId, description) {
    const entry = {
        id: 'log-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5),
        timestamp: new Date().toISOString(),
        type, entity, entityId,
        description: sanitizeActivityDescription(description),
        user: sanitizeHTML(State.user.name)
    };
    State.activityLog.unshift(entry);
    if (State.activityLog.length > 100) State.activityLog = State.activityLog.slice(0, 100);
}

function timeAgo(dateString) {
    const seconds = Math.floor((new Date() - new Date(dateString)) / 1000);
    const intervals = [
        { label: 'año', seconds: 31536000 }, { label: 'mes', seconds: 2592000 },
        { label: 'día', seconds: 86400 }, { label: 'hora', seconds: 3600 }, { label: 'minuto', seconds: 60 }
    ];
    for (const interval of intervals) {
        const count = Math.floor(seconds / interval.seconds);
        if (count >= 1) return `hace ${count} ${interval.label}${count > 1 ? 's' : ''}`;
    }
    return 'hace unos segundos';
}

function getActivityIcon(type) {
    const icons = { unit_created: 'truck', unit_updated: 'edit-2', unit_deleted: 'trash-2', status_changed: 'refresh-cw', driver_created: 'user-plus', driver_updated: 'user', driver_deleted: 'user-x', alert_resolved: 'check-circle', alert_created: 'alert-triangle', maintenance_updated: 'wrench', profile_updated: 'user', plan_changed: 'credit-card' };
    return icons[type] || 'activity';
}

function getActivityCategory(type) {
    if (type.startsWith('unit') || type === 'status_changed' || type === 'maintenance_updated') return 'unit';
    if (type.startsWith('driver')) return 'driver';
    if (type.startsWith('alert')) return 'alert';
    return 'unit';
}

function generateSeedActivity() {
    const now = new Date();
    const entries = [
        { offset: -3600000, type: 'status_changed', entity: 'unit', entityId: 'u-003', description: '<strong>Mercedes Actros</strong> cambió a estado Taller', user: 'Carlos' },
        { offset: -7200000, type: 'alert_created', entity: 'alert', entityId: 'a-001', description: 'Alerta creada: <strong>Mantenimiento Vencido</strong>', user: 'Sistema' },
        { offset: -86400000, type: 'unit_created', entity: 'unit', entityId: 'u-005', description: '<strong>MAN TGX</strong> agregada a la flota', user: 'Carlos' }
    ];
    entries.forEach(entry => {
        State.activityLog.push({
            id: 'log-seed-' + Math.random().toString(36).substr(2, 9),
            timestamp: new Date(now.getTime() + entry.offset).toISOString(),
            type: entry.type, entity: entry.entity, entityId: entry.entityId,
            description: entry.description, user: entry.user
        });
    });
}

function getUpcomingExpirations() {
    const now = new Date();
    const upcoming = [];
    State.fleet.forEach(unit => {
        if (unit.insurance_expiry) {
            const daysUntil = Math.ceil((new Date(unit.insurance_expiry) - now) / (1000 * 60 * 60 * 24));
            if (daysUntil <= 30) {
                upcoming.push({ id: 'ins-' + unit.id, type: 'insurance', unit_id: unit.id, unit_name: unit.unit_name, title: daysUntil < 0 ? 'Seguro vencido' : 'Seguro por vencer', detail: daysUntil < 0 ? `Venció hace ${Math.abs(daysUntil)} días` : `Vence el ${formatDate(unit.insurance_expiry)}`, days: daysUntil, severity: daysUntil <= 7 ? 'critical' : 'warning' });
            }
        }
        if (unit.next_maintenance_date) {
            const daysUntil = Math.ceil((new Date(unit.next_maintenance_date) - now) / (1000 * 60 * 60 * 24));
            if (daysUntil <= 30 && daysUntil >= 0) {
                upcoming.push({ id: 'maint-' + unit.id, type: 'maintenance', unit_id: unit.id, unit_name: unit.unit_name, title: 'Mantenimiento próximo', detail: `Programado para ${formatDate(unit.next_maintenance_date)}`, days: daysUntil, severity: daysUntil <= 7 ? 'critical' : 'warning' });
            }
        }
    });
    return upcoming.sort((a, b) => a.days - b.days);
}

// =========================================
// RENDER FUNCTIONS
// =========================================
function subscribe(listener) { State.listeners.push(listener); }
function notify() { State.listeners.forEach(listener => listener()); }

function renderMetrics() {
    DOM.metricActive.textContent = State.fleet.filter(u => u.status === 'active').length;
    DOM.metricMaintenance.textContent = State.fleet.filter(u => u.status === 'maintenance').length;
    DOM.metricIdle.textContent = State.fleet.filter(u => u.status === 'idle').length;
    DOM.metricAlerts.textContent = State.alerts.filter(a => !a.resolved).length;
}

function renderAlertBadges() {
    const unresolved = State.alerts.filter(a => !a.resolved).length;
    const critical = State.alerts.filter(a => !a.resolved && a.severity === 'critical').length;
    
    const alertBadge = document.getElementById('alert-badge');
    if (unresolved > 0) { alertBadge.style.display = 'flex'; alertBadge.textContent = unresolved > 99 ? '99+' : unresolved; }
    else { alertBadge.style.display = 'none'; }
    
    const criticalBadge = document.getElementById('critical-badge');
    if (critical > 0) { 
        criticalBadge.style.display = 'inline-flex'; 
        document.getElementById('critical-count').textContent = critical; 
    } else { 
        criticalBadge.style.display = 'none'; 
    }
}

function renderAvatar() {
    const avatarImage = document.getElementById('avatar-image');
    const avatarInitials = document.getElementById('avatar-initials');
    if (State.user.avatar_url) { 
        avatarImage.src = sanitizeHTML(State.user.avatar_url); 
        avatarImage.style.display = 'block'; 
        avatarInitials.style.display = 'none'; 
    } else { 
        avatarImage.style.display = 'none'; 
        avatarInitials.style.display = 'flex'; 
        avatarInitials.textContent = State.user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2); 
    }
}

function renderCurrentPlan() {
    const currentPlan = PLANS[State.user.plan];
    const unitsStatus = getLimitStatus(State.fleet.length, currentPlan.limits.units);
    const driversStatus = getLimitStatus(State.drivers.length, currentPlan.limits.drivers);
    
    document.getElementById('current-plan-name').textContent = currentPlan.name;
    document.getElementById('current-plan-price').textContent = currentPlan.price === 0 ? 'Gratis' : `$${currentPlan.price}/mes`;
    
    const unitsLimitEl = document.getElementById('plan-units-limit');
    unitsLimitEl.textContent = unitsStatus.text;
    unitsLimitEl.className = `plan-limit-value ${unitsStatus.class}`;
    
    const driversLimitEl = document.getElementById('plan-drivers-limit');
    driversLimitEl.textContent = driversStatus.text;
    driversLimitEl.className = `plan-limit-value ${driversStatus.class}`;
}

function createFleetItemHTML(unit) {
    return `<div class="fleet-item" data-action="show-unit" data-id="${strictSanitize(unit.id)}">
        <div class="fleet-icon"><i data-lucide="truck"></i></div>
        <div class="fleet-details">
            <div class="fleet-name">${sanitizeHTML(unit.unit_name)}</div>
            <div class="fleet-driver">${sanitizeHTML(unit.driver)}</div>
        </div>
        <span class="status-pill ${sanitizeHTML(unit.status)}">${getStatusLabel(unit.status)}</span>
        <div class="fleet-chevron"><i data-lucide="chevron-right"></i></div>
    </div>`;
}

function createAlertItemHTML(alert) {
    return `<div class="alert-item ${sanitizeHTML(alert.severity)} ${alert.resolved ? 'resolved' : ''}" data-action="show-alert" data-id="${sanitizeHTML(alert.id)}">
        <div class="alert-info">
            <h4>${sanitizeHTML(alert.title)}</h4>
            <p>${sanitizeHTML(alert.desc)}</p>
        </div>
        <button class="alert-action" aria-label="Acción"><i data-lucide="chevron-right"></i></button>
    </div>`;
}

function createUpcomingItemHTML(item) {
    const icon = item.type === 'insurance' ? 'shield' : 'wrench';
    const daysText = item.days < 0 ? 'Vencido' : (item.days === 0 ? 'Hoy' : `${item.days} días`);
    return `<div class="upcoming-item ${sanitizeHTML(item.severity)}" data-action="show-unit" data-id="${sanitizeHTML(item.unit_id)}">
        <div class="upcoming-icon ${sanitizeHTML(item.type)}"><i data-lucide="${icon}"></i></div>
        <div class="upcoming-content">
            <div class="upcoming-title">${sanitizeHTML(item.unit_name)}</div>
            <div class="upcoming-detail">${sanitizeHTML(item.title)} - ${sanitizeHTML(item.detail)}</div>
        </div>
        <div class="upcoming-days ${sanitizeHTML(item.severity)}">${daysText}</div>
    </div>`;
}

function createActivityItemHTML(entry) {
    const category = getActivityCategory(entry.type);
    return `<div class="activity-item">
        <div class="activity-icon ${category}"><i data-lucide="${getActivityIcon(entry.type)}"></i></div>
        <div class="activity-content">
            <div class="activity-description">${entry.description}</div>
            <div class="activity-meta">
                <i data-lucide="clock"></i><span>${timeAgo(entry.timestamp)}</span><span>•</span><span>${sanitizeHTML(entry.user)}</span>
            </div>
        </div>
    </div>`;
}

function createDriverItemHTML(driver) {
    const initials = driver.name.split(' ').map(n => n[0]).join('').toUpperCase();
    const unitsCount = State.fleet.filter(u => u.driver === driver.name).length;
    return `<div class="driver-item" data-id="${sanitizeHTML(driver.id)}">
        <div class="driver-avatar">${initials}</div>
        <div class="driver-info">
            <div class="driver-name">${sanitizeHTML(driver.name)}</div>
            <div class="driver-units">${unitsCount} unidad${unitsCount !== 1 ? 'es' : ''} asignada${unitsCount !== 1 ? 's' : ''}</div>
        </div>
        <div class="driver-actions">
            <button class="driver-action-btn" data-action="edit-driver" data-id="${sanitizeHTML(driver.id)}"><i data-lucide="edit-2"></i></button>
            <button class="driver-action-btn" data-action="delete-driver" data-id="${sanitizeHTML(driver.id)}"><i data-lucide="trash-2"></i></button>
        </div>
    </div>`;
}

function renderDashboardFleet() {
    DOM.fleetContainer.innerHTML = State.fleet.slice(0, 3).map(createFleetItemHTML).join('');
    lucide.createIcons();
}

function renderDashboardAlerts() {
    DOM.alertsContainer.innerHTML = State.alerts.filter(a => !a.resolved).slice(0, 2).map(createAlertItemHTML).join('');
    lucide.createIcons();
}

function renderDashboardUpcoming() {
    const upcoming = getUpcomingExpirations().slice(0, 3);
    const upcomingSection = document.getElementById('upcoming-section');
    if (upcoming.length === 0) { upcomingSection.style.display = 'none'; }
    else { 
        upcomingSection.style.display = 'block'; 
        DOM.upcomingContainer.innerHTML = upcoming.map(createUpcomingItemHTML).join(''); 
    }
    lucide.createIcons();
}

function renderUpcomingFull() {
    const upcoming = getUpcomingExpirations();
    DOM.upcomingFullContainer.innerHTML = upcoming.length === 0 
        ? '<div class="empty-state"><i data-lucide="check-circle"></i><h3>Sin vencimientos</h3><p>Todo está al día</p></div>'
        : upcoming.map(createUpcomingItemHTML).join('');
    lucide.createIcons();
}

function renderDashboardActivity() {
    const recent = State.activityLog.slice(0, 4);
    DOM.activityContainer.innerHTML = recent.length === 0 
        ? '<div class="empty-state"><i data-lucide="activity"></i><h3>Sin actividad</h3><p>Las acciones aparecerán aquí</p></div>'
        : recent.map(createActivityItemHTML).join('');
    lucide.createIcons();
}

function renderFleetFull() {
    let filtered = [...State.fleet];
    if (State.filters.fleet.status !== 'all') filtered = filtered.filter(u => u.status === State.filters.fleet.status);
    if (State.filters.fleet.search) {
        const search = State.filters.fleet.search.toLowerCase();
        filtered = filtered.filter(u => u.unit_name.toLowerCase().includes(search) || u.driver.toLowerCase().includes(search));
    }
    DOM.fleetFullContainer.innerHTML = filtered.length === 0 
        ? '<div class="empty-state"><i data-lucide="search-x"></i><h3>Sin resultados</h3><p>Intenta con otros filtros</p></div>'
        : filtered.map(createFleetItemHTML).join('');
    lucide.createIcons();
}

function renderAlertsFull() {
    let filtered = [...State.alerts];
    if (State.filters.alerts.severity === 'critical') filtered = filtered.filter(a => a.severity === 'critical' && !a.resolved);
    else if (State.filters.alerts.severity === 'warning') filtered = filtered.filter(a => a.severity === 'warning' && !a.resolved);
    else if (State.filters.alerts.severity === 'resolved') filtered = filtered.filter(a => a.resolved);
    
    DOM.alertsFullContainer.innerHTML = filtered.length === 0 
        ? '<div class="empty-state"><i data-lucide="check-circle"></i><h3>Sin alertas</h3><p>Todo está en orden</p></div>'
        : filtered.map(createAlertItemHTML).join('');
    lucide.createIcons();
}

function renderActivityFull() {
    let filtered = [...State.activityLog];
    if (State.filters.activity.type !== 'all') filtered = filtered.filter(a => getActivityCategory(a.type) === State.filters.activity.type);
    
    DOM.activityFullContainer.innerHTML = filtered.length === 0 
        ? '<div class="empty-state"><i data-lucide="activity"></i><h3>Sin actividad</h3><p>No hay registros en esta categoría</p></div>'
        : filtered.map(createActivityItemHTML).join('');
    lucide.createIcons();
}

function renderDrivers() {
    let filtered = [...State.drivers];
    if (State.filters.drivers.search) {
        const search = State.filters.drivers.search.toLowerCase();
        filtered = filtered.filter(d => d.name.toLowerCase().includes(search));
    }
    DOM.driversContainer.innerHTML = filtered.length === 0 
        ? '<div class="empty-state"><i data-lucide="search-x"></i><h3>Sin resultados</h3></div>'
        : filtered.map(createDriverItemHTML).join('');
    lucide.createIcons();
}

// =========================================
// SHEETS & MODALS
// =========================================
function openSheet(content) { 
    DOM.sheetContent.innerHTML = content; 
    DOM.sheetOverlay.classList.add('active'); 
    DOM.bottomSheet.classList.add('active'); 
    document.body.style.overflow = 'hidden'; 
    lucide.createIcons(); 
}

function closeSheet() { 
    DOM.sheetOverlay.classList.remove('active'); 
    DOM.bottomSheet.classList.remove('active');
    DOM.bottomSheet.classList.remove('dragging');
    DOM.bottomSheet.classList.remove('closing');
    DOM.bottomSheet.style.transform = ''; // Limpia estilo inline del drag
    DOM.sheetOverlay.style.opacity = ''; // Limpia estilo inline del drag
    document.body.style.overflow = ''; 
}

function openModal(title, body, footer) { 
    DOM.modalTitle.textContent = sanitizeHTML(title); 
    DOM.modalBody.innerHTML = body; 
    DOM.modalFooter.innerHTML = footer; 
    DOM.modalOverlay.classList.add('active'); 
    DOM.modal.classList.add('active'); 
    document.body.style.overflow = 'hidden'; 
    lucide.createIcons(); 
}

function closeModal() { 
    DOM.modalOverlay.classList.remove('active'); 
    DOM.modal.classList.remove('active'); 
    document.body.style.overflow = ''; 
}

// =========================================
// ACTIONS (Called via Event Delegation)
// =========================================
function showUnitDetail(unitId) {
    const unit = State.fleet.find(u => u.id === unitId);
    if (!unit) return;
    
    const unitActivity = State.activityLog.filter(a => a.entityId === unitId).slice(0, 10);
    let maintenanceSection = '';
    if (unit.status === 'maintenance' && unit.maintenance_info) {
        const info = unit.maintenance_info;
        maintenanceSection = `
            <div class="sheet-section">
                <div class="sheet-section-title">Información de Taller</div>
                <div class="sheet-info-row"><span class="sheet-info-label">Fecha de entrada</span><span class="sheet-info-value">${formatDate(info.entry_date)}</span></div>
                <div class="sheet-info-row"><span class="sheet-info-label">Problema</span><span class="sheet-info-value">${sanitizeHTML(info.issue)}</span></div>
                <div class="sheet-info-row"><span class="sheet-info-label">Piezas requeridas</span><span class="sheet-info-value">${sanitizeHTML(info.parts_needed)}</span></div>
                <div class="sheet-info-row"><span class="sheet-info-label">Mecánico</span><span class="sheet-info-value">${sanitizeHTML(info.mechanic)}</span></div>
                <div class="sheet-info-row"><span class="sheet-info-label">Salida estimada</span><span class="sheet-info-value">${formatDate(info.estimated_exit)}</span></div>
            </div>`;
    }
    
    let activitySection = '';
    if (unitActivity.length > 0) {
        activitySection = `<div class="sheet-section"><div class="sheet-section-title">Historial de Actividad</div><div class="activity-list" style="padding: 0;">${unitActivity.map(createActivityItemHTML).join('')}</div></div>`;
    }
    
    const content = `
        <h3 class="sheet-title">${sanitizeHTML(unit.unit_name)}</h3>
        <div class="sheet-section">
            <div class="sheet-section-title">Información</div>
            <div class="sheet-info-row"><span class="sheet-info-label">Conductor</span><span class="sheet-info-value">${sanitizeHTML(unit.driver)}</span></div>
            <div class="sheet-info-row"><span class="sheet-info-label">Placa</span><span class="sheet-info-value">${sanitizeHTML(unit.plate)}</span></div>
            <div class="sheet-info-row"><span class="sheet-info-label">Año</span><span class="sheet-info-value">${unit.year}</span></div>
            <div class="sheet-info-row"><span class="sheet-info-label">Kilometraje</span><span class="sheet-info-value">${unit.mileage.toLocaleString()} km</span></div>
            <div class="sheet-info-row"><span class="sheet-info-label">Estado</span><span class="sheet-info-value"><span class="status-pill ${sanitizeHTML(unit.status)}">${getStatusLabel(unit.status)}</span></span></div>
            ${unit.status_comment ? `<div class="sheet-info-row"><span class="sheet-info-label">Motivo</span><span class="sheet-info-value">${sanitizeHTML(unit.status_comment)}</span></div>` : ''}
            ${unit.insurance_expiry ? `<div class="sheet-info-row"><span class="sheet-info-label">Seguro</span><span class="sheet-info-value">${formatDate(unit.insurance_expiry)}</span></div>` : ''}
        </div>
        ${maintenanceSection}
        ${activitySection}
        <div class="sheet-section">
            <div class="sheet-section-title">Acciones</div>
            <div class="sheet-actions">
                <button class="sheet-btn" data-action="edit-unit" data-id="${strictSanitize(unit.id)}"><i data-lucide="edit-2"></i><span>Editar Unidad</span></button>
                <button class="sheet-btn" data-action="change-status" data-id="${strictSanitize(unit.id)}"><i data-lucide="refresh-cw"></i><span>Cambiar Estado</span></button>
                ${unit.status === 'maintenance' ? `<button class="sheet-btn" data-action="edit-maintenance" data-id="${strictSanitize(unit.id)}"><i data-lucide="wrench"></i><span>Editar Info de Taller</span></button>` : ''}
                <button class="sheet-btn danger" data-action="delete-unit" data-id="${strictSanitize(unit.id)}"><i data-lucide="trash-2"></i><span>Eliminar Unidad</span></button>
            </div>
        </div>`;
    openSheet(content);
}

function showAlertDialog(alertId) {
    const alert = State.alerts.find(a => a.id === alertId);
    if (!alert) return;
    const unit = State.fleet.find(u => u.id === alert.unit_id);
    
    const content = `
        <h3 class="sheet-title">${sanitizeHTML(alert.title)}</h3>
        <div class="sheet-section">
            <div class="sheet-info-row"><span class="sheet-info-label">Unidad</span><span class="sheet-info-value">${unit ? sanitizeHTML(unit.unit_name) : 'N/A'}</span></div>
            <div class="sheet-info-row"><span class="sheet-info-label">Detalle</span><span class="sheet-info-value">${sanitizeHTML(alert.desc)}</span></div>
            <div class="sheet-info-row"><span class="sheet-info-label">Severidad</span><span class="sheet-info-value"><span class="status-pill ${alert.severity === 'critical' ? 'maintenance' : 'idle'}">${sanitizeHTML(alert.severity)}</span></span></div>
        </div>
        ${!alert.resolved ? `<div class="sheet-section"><div class="sheet-actions"><button class="sheet-btn" data-action="resolve-alert" data-id="${sanitizeHTML(alert.id)}"><i data-lucide="check-circle"></i><span>Marcar como Resuelta</span></button></div></div>` : ''}`;
    openSheet(content);
}

function editUnit(unitId) {
    closeSheet();
    const unit = State.fleet.find(u => u.id === unitId);
    if (!unit) return;
    
    const body = `
        <div class="form-group"><label class="form-label">Nombre de Unidad</label><input type="text" class="form-input" id="edit-unit-name" value="${sanitizeHTML(unit.unit_name)}"></div>
        <div class="form-group"><label class="form-label">Conductor</label><input type="text" class="form-input" id="edit-unit-driver" value="${sanitizeHTML(unit.driver)}"></div>
        <div class="form-group"><label class="form-label">Placa</label><input type="text" class="form-input" id="edit-unit-plate" value="${sanitizeHTML(unit.plate)}" placeholder="ABC-123"></div>
        <div class="form-group"><label class="form-label">Año</label><input type="number" class="form-input" id="edit-unit-year" value="${unit.year}" min="1900" max="${new Date().getFullYear() + 1}"></div>
        <div class="form-group"><label class="form-label">Kilometraje</label><input type="number" class="form-input" id="edit-unit-mileage" value="${unit.mileage}" min="0"></div>
        <div class="form-group"><label class="form-label">Vencimiento Seguro</label><input type="date" class="form-input" id="edit-unit-insurance" value="${unit.insurance_expiry || ''}"></div>
        <div class="form-group"><label class="form-label">Próx. Mant. (km)</label><input type="number" class="form-input" id="edit-unit-maint-km" value="${unit.next_maintenance_km || ''}" min="0"></div>
        <div class="form-group"><label class="form-label">Próx. Mant. (fecha)</label><input type="date" class="form-input" id="edit-unit-maint-date" value="${unit.next_maintenance_date || ''}"></div>`;
    const footer = `<button class="btn-secondary" data-action="close-modal">Cancelar</button><button class="btn-modal-primary" data-action="save-unit-edit" data-id="${strictSanitize(unit.id)}">Guardar</button>`;
    openModal('Editar Unidad', body, footer);
}

function saveUnitEdit(unitId) {
    const unit = State.fleet.find(u => u.id === unitId);
    if (!unit) return;
    const oldName = unit.unit_name;
    
    unit.unit_name = document.getElementById('edit-unit-name').value;
    unit.driver = document.getElementById('edit-unit-driver').value;
    unit.plate = document.getElementById('edit-unit-plate').value;
    unit.year = parseInt(document.getElementById('edit-unit-year').value);
    unit.mileage = parseInt(document.getElementById('edit-unit-mileage').value);
    unit.insurance_expiry = document.getElementById('edit-unit-insurance').value;
    unit.next_maintenance_km = parseInt(document.getElementById('edit-unit-maint-km').value) || null;
    unit.next_maintenance_date = document.getElementById('edit-unit-maint-date').value;
    
    logActivity('unit_updated', 'unit', unitId, `<strong>${sanitizeHTML(oldName)}</strong> actualizada`);
    closeModal();
    notify();
    showToast('Unidad actualizada');
}

function changeStatus(unitId) {
    closeSheet();
    const unit = State.fleet.find(u => u.id === unitId);
    if (!unit) return;
    
    const body = `
        <div class="form-group">
            <label class="form-label">Nuevo Estado</label>
            <select class="form-select" id="change-status-select">
                <option value="active" ${unit.status === 'active' ? 'selected' : ''}>Activa</option>
                <option value="maintenance" ${unit.status === 'maintenance' ? 'selected' : ''}>Taller</option>
                <option value="idle" ${unit.status === 'idle' ? 'selected' : ''}>Inactiva</option>
            </select>
        </div>
        <div class="form-group" id="status-comment-group" style="display: none;">
            <label class="form-label">Motivo</label>
            <textarea class="form-textarea" id="change-status-comment" placeholder="Explica por qué cambia el estado..."></textarea>
            <p class="form-hint">Obligatorio para estados Taller e Inactiva</p>
        </div>`;
    const footer = `<button class="btn-secondary" data-action="close-modal">Cancelar</button><button class="btn-modal-primary" data-action="save-status-change" data-id="${strictSanitize(unit.id)}">Cambiar</button>`;
    openModal('Cambiar Estado', body, footer);
    
    setTimeout(() => { 
        const select = document.getElementById('change-status-select'); 
        const commentGroup = document.getElementById('status-comment-group'); 
        select.addEventListener('change', (e) => { commentGroup.style.display = (e.target.value === 'maintenance' || e.target.value === 'idle') ? 'block' : 'none'; }); 
        if (select.value === 'maintenance' || select.value === 'idle') commentGroup.style.display = 'block'; 
    }, 100);
}

function saveStatusChange(unitId) {
    const unit = State.fleet.find(u => u.id === unitId);
    if (!unit) return;
    const newStatus = document.getElementById('change-status-select').value;
    const comment = document.getElementById('change-status-comment').value.trim();
    const oldStatus = unit.status;
    
    if ((newStatus === 'maintenance' || newStatus === 'idle') && !comment) { showToast('El motivo es obligatorio'); return; }
    
    unit.status = newStatus;
    unit.status_comment = comment;
    logActivity('status_changed', 'unit', unitId, `<strong>${sanitizeHTML(unit.unit_name)}</strong> cambió de ${getStatusLabel(oldStatus)} a ${getStatusLabel(newStatus)}`);
    
    if (newStatus === 'maintenance') { 
        closeModal(); 
        setTimeout(() => editMaintenanceInfo(unitId), 300); 
    } else { 
        if (newStatus !== 'maintenance') unit.maintenance_info = null; 
        closeModal(); 
        notify(); 
        showToast('Estado cambiado a ' + getStatusLabel(newStatus)); 
    }
}

function editMaintenanceInfo(unitId) {
    closeSheet();
    const unit = State.fleet.find(u => u.id === unitId);
    if (!unit) return;
    const info = unit.maintenance_info || { entry_date: new Date().toISOString().split('T')[0], issue: '', parts_needed: '', mechanic: '', estimated_exit: '' };
    
    const body = `
        <div class="form-group"><label class="form-label">Fecha de Entrada</label><input type="date" class="form-input" id="maint-entry-date" value="${info.entry_date}"></div>
        <div class="form-group"><label class="form-label">Problema / Diagnóstico</label><textarea class="form-textarea" id="maint-issue" placeholder="Describe el problema...">${sanitizeHTML(info.issue)}</textarea></div>
        <div class="form-group"><label class="form-label">Piezas Requeridas</label><textarea class="form-textarea" id="maint-parts" placeholder="Lista de piezas necesarias...">${sanitizeHTML(info.parts_needed)}</textarea></div>
        <div class="form-group"><label class="form-label">Mecánico / Taller</label><input type="text" class="form-input" id="maint-mechanic" value="${sanitizeHTML(info.mechanic)}" placeholder="Nombre del taller o mecánico"></div>
        <div class="form-group"><label class="form-label">Fecha Estimada de Salida</label><input type="date" class="form-input" id="maint-estimated-exit" value="${info.estimated_exit}"></div>`;
    const footer = `<button class="btn-secondary" data-action="close-modal">Cancelar</button><button class="btn-modal-primary" data-action="save-maintenance-info" data-id="${strictSanitize(unit.id)}">Guardar</button>`;
    openModal('Información de Taller', body, footer);
}

function saveMaintenanceInfo(unitId) {
    const unit = State.fleet.find(u => u.id === unitId);
    if (!unit) return;
    unit.maintenance_info = { 
        entry_date: document.getElementById('maint-entry-date').value, 
        issue: document.getElementById('maint-issue').value, 
        parts_needed: document.getElementById('maint-parts').value, 
        mechanic: document.getElementById('maint-mechanic').value, 
        estimated_exit: document.getElementById('maint-estimated-exit').value 
    };
    logActivity('maintenance_updated', 'unit', unitId, `Información de taller actualizada para <strong>${sanitizeHTML(unit.unit_name)}</strong>`);
    closeModal();
    notify();
    showToast('Información de taller actualizada');
}

function deleteUnit(unitId) {
    closeSheet();
    const unit = State.fleet.find(u => u.id === unitId);
    const body = `<p>¿Estás seguro de que deseas eliminar <strong>${unit ? sanitizeHTML(unit.unit_name) : 'esta unidad'}</strong>? Esta acción no se puede deshacer.</p>`;
    const footer = `<button class="btn-secondary" data-action="close-modal">Cancelar</button><button class="btn-modal-primary" style="background: var(--color-critical);" data-action="confirm-delete-unit" data-id="${sanitizeHTML(unitId)}">Eliminar</button>`;
    openModal('Eliminar Unidad', body, footer);
}

function confirmDeleteUnit(unitId) {
    const unit = State.fleet.find(u => u.id === unitId);
    if (unit) logActivity('unit_deleted', 'unit', unitId, `<strong>${sanitizeHTML(unit.unit_name)}</strong> eliminada de la flota`);
    State.fleet = State.fleet.filter(u => u.id !== unitId);
    closeModal();
    notify();
    showToast('Unidad eliminada');
}

function resolveAlert(alertId) {
    const alert = State.alerts.find(a => a.id === alertId);
    if (!alert) return;
    alert.resolved = true;
    logActivity('alert_resolved', 'alert', alertId, `Alerta resuelta: <strong>${sanitizeHTML(alert.title)}</strong>`);
    closeSheet();
    notify();
    showToast('Alerta resuelta');
}

function addUnit() {
    const body = `
        <div class="form-group"><label class="form-label">Nombre de Unidad</label><input type="text" class="form-input" id="new-unit-name" placeholder="Ej: Volvo FH16"></div>
        <div class="form-group"><label class="form-label">Conductor</label><input type="text" class="form-input" id="new-unit-driver" placeholder="Nombre del conductor"></div>
        <div class="form-group"><label class="form-label">Placa</label><input type="text" class="form-input" id="new-unit-plate" placeholder="ABC-123"></div>
        <div class="form-group"><label class="form-label">Año</label><input type="number" class="form-input" id="new-unit-year" placeholder="2023"></div>`;
    const footer = `<button class="btn-secondary" data-action="close-modal">Cancelar</button><button class="btn-modal-primary" data-action="save-new-unit">Agregar</button>`;
    openModal('Nueva Unidad', body, footer);
}

function saveNewUnit() {
    if (!checkUnitLimit()) { closeModal(); return; }
    
    const name = document.getElementById('new-unit-name').value.trim();
    const driver = document.getElementById('new-unit-driver').value.trim();
    const plate = document.getElementById('new-unit-plate').value.trim().toUpperCase();
    const year = safeParseInt(document.getElementById('new-unit-year').value, 1900, new Date().getFullYear() + 1);
    
    // Validaciones
    if (!name || !driver || !plate) { 
        showToast('Completa todos los campos'); 
        return; 
    }
    if (year === null) { 
        showToast('Año inválido'); 
        return; 
    }
    
    const newUnit = { 
        id: 'u-' + Date.now(), 
        unit_name: name, 
        driver, 
        plate, 
        year, 
        mileage: 0, 
        status: 'idle', 
        status_comment: 'Unidad recién agregada', 
        maintenance_info: null, 
        insurance_expiry: '', 
        next_maintenance_km: null, 
        next_maintenance_date: '' 
    };
    
    State.fleet.unshift(newUnit);
    logActivity('unit_created', 'unit', newUnit.id, `<strong>${sanitizeHTML(name)}</strong> agregada a la flota`);
    closeModal();
    notify();
    showToast('Unidad agregada');
}

function editProfile() {
    const body = `
        <div class="form-group"><label class="form-label">Foto de Perfil (URL)</label><input type="url" class="form-input" id="profile-avatar" value="${sanitizeHTML(State.user.avatar_url)}" placeholder="https://ejemplo.com/foto.jpg"><p class="form-hint">Deja vacío para usar iniciales</p></div>
        <div class="form-group"><label class="form-label">Nombre</label><input type="text" class="form-input" id="profile-name" value="${sanitizeHTML(State.user.name)}"></div>
        <div class="form-group"><label class="form-label">Email</label><input type="email" class="form-input" id="profile-email" value="${sanitizeHTML(State.user.email)}"></div>
        <div class="form-group"><label class="form-label">Rol</label><input type="text" class="form-input" id="profile-role" value="${sanitizeHTML(State.user.role)}" readonly></div>`;
    const footer = `<button class="btn-secondary" data-action="close-modal">Cancelar</button><button class="btn-modal-primary" data-action="save-profile">Guardar</button>`;
    openModal('Editar Perfil', body, footer);
}

function saveProfile() {
    const avatar_url = document.getElementById('profile-avatar').value.trim();
    const name = document.getElementById('profile-name').value.trim();
    const email = document.getElementById('profile-email').value.trim();
    
    // 1. Validar URL de imagen
    if (avatar_url && !isValidImageUrl(avatar_url)) {
        showToast('URL de imagen inválida. Debe empezar con http:// o https://');
        return;
    }
    
    // 2. Validar campos vacíos
    if (!name || !email) {
        showToast('Nombre y email son obligatorios');
        return;
    }

    State.user.avatar_url = avatar_url;
    State.user.name = name;
    State.user.email = email;
    
    document.querySelector('.greeting-name').textContent = sanitizeHTML(State.user.name);
    logActivity('profile_updated', 'user', 'self', `Perfil actualizado por <strong>${sanitizeHTML(State.user.name)}</strong>`);
    
    closeModal();
    notify();
    showToast('Perfil actualizado');
}

function showProfileSheet() {
    const initials = State.user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2);
    const avatarHtml = State.user.avatar_url 
        ? `<img src="${sanitizeHTML(State.user.avatar_url)}" class="profile-sheet-avatar-img" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
           <div class="profile-sheet-avatar-fallback" style="display:none;">${initials}</div>`
        : `<div class="profile-sheet-avatar-fallback">${initials}</div>`;

    const content = `
        <div class="profile-sheet-header">
            <div class="profile-sheet-avatar">
                ${avatarHtml}
            </div>
            <h3 class="profile-sheet-name">${sanitizeHTML(State.user.name)}</h3>
            <p class="profile-sheet-email">${sanitizeHTML(State.user.email)}</p>
            <span class="profile-sheet-role">${sanitizeHTML(State.user.role)}</span>
        </div>
        <div class="profile-sheet-actions">
            <button class="sheet-btn" data-action="edit-profile">
                <i data-lucide="user"></i>
                <span>Editar Perfil</span>
            </button>
            <button class="sheet-btn" data-nav="settings">
                <i data-lucide="settings"></i>
                <span>Configuración</span>
            </button>
            <button class="sheet-btn danger" data-action="logout">
                <i data-lucide="log-out"></i>
                <span>Cerrar Sesión (Demo)</span>
            </button>
        </div>
    `;
    openSheet(content);
}

function addDriver() {
    const body = `
        <div class="form-group"><label class="form-label">Nombre Completo</label><input type="text" class="form-input" id="new-driver-name" placeholder="Ej: Juan Pérez"></div>
        <div class="form-group"><label class="form-label">Teléfono</label><input type="tel" class="form-input" id="new-driver-phone" placeholder="+52 555 123 4567"></div>
        <div class="form-group"><label class="form-label">Licencia</label><input type="text" class="form-input" id="new-driver-license" placeholder="A-12345"></div>`;
    const footer = `<button class="btn-secondary" data-action="close-modal">Cancelar</button><button class="btn-modal-primary" data-action="save-new-driver">Agregar</button>`;
    openModal('Nuevo Conductor', body, footer);
}

function saveNewDriver() {
    if (!checkDriverLimit()) { closeModal(); return; }
    const name = document.getElementById('new-driver-name').value;
    const phone = document.getElementById('new-driver-phone').value;
    const license = document.getElementById('new-driver-license').value;
    
    if (!name || !phone || !license) { showToast('Completa todos los campos'); return; }
    
    const newDriver = { id: 'd-' + Date.now(), name, phone, license };
    State.drivers.push(newDriver);
    logActivity('driver_created', 'driver', newDriver.id, `<strong>${sanitizeHTML(name)}</strong> registrado como conductor`);
    closeModal();
    renderDrivers();
    notify();
    showToast('Conductor agregado');
}

function editDriver(driverId) {
    const driver = State.drivers.find(d => d.id === driverId);
    if (!driver) return;
    const body = `
        <div class="form-group"><label class="form-label">Nombre Completo</label><input type="text" class="form-input" id="edit-driver-name" value="${sanitizeHTML(driver.name)}"></div>
        <div class="form-group"><label class="form-label">Teléfono</label><input type="tel" class="form-input" id="edit-driver-phone" value="${sanitizeHTML(driver.phone)}"></div>
        <div class="form-group"><label class="form-label">Licencia</label><input type="text" class="form-input" id="edit-driver-license" value="${sanitizeHTML(driver.license)}"></div>`;
    const footer = `<button class="btn-secondary" data-action="close-modal">Cancelar</button><button class="btn-modal-primary" data-action="save-driver-edit" data-id="${sanitizeHTML(driver.id)}">Guardar</button>`;
    openModal('Editar Conductor', body, footer);
}

function saveDriverEdit(driverId) {
    const driver = State.drivers.find(d => d.id === driverId);
    if (!driver) return;
    const oldName = driver.name;
    driver.name = document.getElementById('edit-driver-name').value;
    driver.phone = document.getElementById('edit-driver-phone').value;
    driver.license = document.getElementById('edit-driver-license').value;
    logActivity('driver_updated', 'driver', driverId, `Conductor <strong>${sanitizeHTML(oldName)}</strong> actualizado`);
    closeModal();
    renderDrivers();
    showToast('Conductor actualizado');
}

function deleteDriver(driverId) {
    const driver = State.drivers.find(d => d.id === driverId);
    if (!driver) return;
    const body = `<p>¿Estás seguro de que deseas eliminar a <strong>${sanitizeHTML(driver.name)}</strong>?</p>`;
    const footer = `<button class="btn-secondary" data-action="close-modal">Cancelar</button><button class="btn-modal-primary" style="background: var(--color-critical);" data-action="confirm-delete-driver" data-id="${sanitizeHTML(driverId)}">Eliminar</button>`;
    openModal('Eliminar Conductor', body, footer);
}

function confirmDeleteDriver(driverId) {
    const driver = State.drivers.find(d => d.id === driverId);
    if (driver) logActivity('driver_deleted', 'driver', driverId, `Conductor <strong>${sanitizeHTML(driver.name)}</strong> eliminado`);
    State.drivers = State.drivers.filter(d => d.id !== driverId);
    closeModal();
    renderDrivers();
    notify();
    showToast('Conductor eliminado');
}

function syncData() {
    const btn = document.querySelector('[data-action="sync-data"]');
    const originalContent = btn.innerHTML;
    btn.innerHTML = '<i data-lucide="loader-2"></i><span>Sincronizando...</span>';
    btn.disabled = true;
    lucide.createIcons();
    setTimeout(() => { btn.innerHTML = originalContent; btn.disabled = false; lucide.createIcons(); showToast('Datos sincronizados'); }, 2000);
}

function logout() {
    const body = `<p>¿Estás seguro de que deseas cerrar sesión?</p>`;
    const footer = `<button class="btn-secondary" data-action="close-modal">Cancelar</button><button class="btn-modal-primary" style="background: var(--color-critical);" data-action="confirm-logout">Cerrar Sesión</button>`;
    openModal('Cerrar Sesión', body, footer);
}

function confirmLogout() { 
    closeModal(); 
    showToast('Sesión cerrada'); 
    setTimeout(() => { window.location.href = 'index.html'; }, 1000);
}

function showUpgradeModal() {
    const currentPlanId = State.user.plan;
    const plansHTML = Object.values(PLANS).map(plan => {
        const isCurrent = plan.id === currentPlanId;
        const features = [
            (plan.limits.units === Infinity ? 'Ilimitadas' : plan.limits.units) + ' unidades',
            (plan.limits.drivers === Infinity ? 'Ilimitados' : plan.limits.drivers) + ' conductores',
            'Alertas ' + (plan.limits.alerts === 'advanced' ? 'avanzadas' : 'básicas')
        ];
        return `<div class="plan-option ${isCurrent ? 'current' : ''}" data-action="${isCurrent ? '' : 'select-plan'}" data-id="${plan.id}">
            <div class="plan-option-header">
                <span class="plan-option-name">${plan.name}</span>
                <span class="plan-option-price">${plan.price === 0 ? 'Gratis' : '$' + plan.price + '/mes'}</span>
            </div>
            <ul class="plan-option-features">${features.map(f => `<li>${f}</li>`).join('')}</ul>
        </div>`;
    }).join('');
    
    const body = `<div class="plans-grid">${plansHTML}</div>`;
    const footer = `<button class="btn-secondary" data-action="close-modal">Cancelar</button>`;
    openModal('Mejorar Plan', body, footer);
}

function selectPlan(planId) {
    if (planId === State.user.plan) return;
    
    // EN DEMO: Interceptamos el upgrade para convertirlo en un llamado a la acción
    const planName = PLANS[planId].name;
    
    showToast(`🚀 ¡Excelente elección! Para activar el plan ${planName} ilimitado, regístrate gratis.`);
    
    // Registramos la actividad como un "intento" en la demo
    logActivity('plan_changed', 'user', 'self', `Intentó mejorar a <strong>${planName}</strong> (Modo Demo)`);
    
    closeModal();
    
    // Opcional: Redirigir al registro después de un breve retraso para capitalizar el interés
    setTimeout(() => {
        window.location.href = 'auth.html?mode=register';
    }, 1500);
}

function resetDemo() {
    localStorage.removeItem('fleet_os_state_v1');
    location.reload();
}

// =========================================
// EVENT DELEGATION (The Elite Way)
// =========================================
document.addEventListener('click', (e) => {
    const target = e.target.closest('[data-action]');
    if (!target) return;
    
    e.preventDefault();
    const action = target.dataset.action;
    const id = target.dataset.id;

    switch(action) {
        case 'show-unit': showUnitDetail(id); break;
        case 'show-alert': showAlertDialog(id); break;
        case 'edit-unit': editUnit(id); break;
        case 'save-unit-edit': saveUnitEdit(id); break;
        case 'change-status': changeStatus(id); break;
        case 'save-status-change': saveStatusChange(id); break;
        case 'edit-maintenance': editMaintenanceInfo(id); break;
        case 'save-maintenance-info': saveMaintenanceInfo(id); break;
        case 'delete-unit': deleteUnit(id); break;
        case 'confirm-delete-unit': confirmDeleteUnit(id); break;
        case 'resolve-alert': resolveAlert(id); break;
        case 'add-unit': addUnit(); break;
        case 'save-new-unit': saveNewUnit(); break;
        case 'edit-profile': editProfile(); break;
        case 'save-profile': saveProfile(); break;
        case 'show-profile': showProfileSheet(); break;
        case 'add-driver': addDriver(); break;
        case 'save-new-driver': saveNewDriver(); break;
        case 'edit-driver': editDriver(id); break;
        case 'save-driver-edit': saveDriverEdit(id); break;
        case 'delete-driver': deleteDriver(id); break;
        case 'confirm-delete-driver': confirmDeleteDriver(id); break;
        case 'upgrade-plan': showUpgradeModal(); break;
        case 'select-plan': selectPlan(id); break;
        case 'sync-data': syncData(); break;
        case 'logout': logout(); break;
        case 'confirm-logout': confirmLogout(); break;
        case 'reset-demo': resetDemo(); break;
        case 'close-modal': closeModal(); break;
        case 'close-search': 
            document.getElementById('search-overlay').classList.remove('active'); 
            document.getElementById('search-modal').classList.remove('active'); 
            break;
        case 'manage-drivers':
    // Navegar a la vista de drivers
    document.getElementById('view-drivers').classList.add('active');
    document.querySelectorAll('.view').forEach(v => { 
        if (v.id !== 'view-drivers') v.classList.remove('active'); 
    });
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    renderDrivers();
    break;
    }
});

// Navigation & Filters
document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => {
        const targetView = item.dataset.view;
        document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
        item.classList.add('active');
        document.querySelectorAll('.view').forEach(view => { 
            view.classList.remove('active'); 
            if (view.id === 'view-' + targetView) view.classList.add('active'); 
        });
    });
});

document.querySelectorAll('[data-nav]').forEach(btn => {
    btn.addEventListener('click', () => {
        const target = btn.dataset.nav;
        document.querySelector(`[data-view="${target}"]`).click();
    });
});

document.querySelectorAll('#view-fleet .chip').forEach(chip => {
    chip.addEventListener('click', () => { 
        document.querySelectorAll('#view-fleet .chip').forEach(c => c.classList.remove('active')); 
        chip.classList.add('active'); 
        State.filters.fleet.status = chip.dataset.status; 
        renderFleetFull(); 
    });
});

document.querySelectorAll('#view-alerts .chip').forEach(chip => {
    chip.addEventListener('click', () => { 
        document.querySelectorAll('#view-alerts .chip').forEach(c => c.classList.remove('active')); 
        chip.classList.add('active'); 
        State.filters.alerts.severity = chip.dataset.severity; 
        renderAlertsFull(); 
    });
});

document.querySelectorAll('#view-activity .chip').forEach(chip => {
    chip.addEventListener('click', () => { 
        document.querySelectorAll('#view-activity .chip').forEach(c => c.classList.remove('active')); 
        chip.classList.add('active'); 
        State.filters.activity.type = chip.dataset.activityType; 
        renderActivityFull(); 
    });
});

document.getElementById('fleet-search').addEventListener('input', (e) => { State.filters.fleet.search = e.target.value; renderFleetFull(); });
document.getElementById('driver-search').addEventListener('input', (e) => { State.filters.drivers.search = e.target.value; renderDrivers(); });

document.getElementById('btn-global-search').addEventListener('click', () => { 
    document.getElementById('search-overlay').classList.add('active'); 
    document.getElementById('search-modal').classList.add('active'); 
    setTimeout(() => document.getElementById('global-search-input').focus(), 100); 
    lucide.createIcons(); 
});

document.getElementById('critical-badge').addEventListener('click', () => { 
    document.querySelector('[data-view="alerts"]').click(); 
    setTimeout(() => { 
        document.querySelectorAll('#view-alerts .chip').forEach(c => c.classList.remove('active')); 
        const criticalChip = document.querySelector('#view-alerts .chip[data-severity="critical"]'); 
        if (criticalChip) { criticalChip.classList.add('active'); State.filters.alerts.severity = 'critical'; renderAlertsFull(); } 
    }, 100); 
});

document.getElementById('sheet-overlay').addEventListener('click', closeSheet);
document.getElementById('modal-overlay').addEventListener('click', closeModal);

document.getElementById('toggle-notifications').addEventListener('change', (e) => { 
    State.preferences.notifications = e.target.checked; 
    showToast(e.target.checked ? 'Notificaciones activadas' : 'Notificaciones desactivadas'); 
});

document.getElementById('toggle-dark-mode').addEventListener('change', (e) => { 
    State.preferences.darkMode = e.target.checked; 
    document.body.classList.toggle('dark-mode', e.target.checked); 
    showToast(e.target.checked ? 'Modo oscuro activado' : 'Modo claro activado'); 
});

document.addEventListener('keydown', (e) => { 
    if (e.key === 'Escape') { 
        if (DOM.modal.classList.contains('active')) closeModal(); 
        if (DOM.bottomSheet.classList.contains('active')) closeSheet(); 
        if (document.getElementById('search-modal').classList.contains('active')) { 
            document.getElementById('search-overlay').classList.remove('active'); 
            document.getElementById('search-modal').classList.remove('active'); 
        } 
    } 
});

// =========================================
// DRAG TO DISMISS (Bottom Sheet) - Corregido
// =========================================
(function initDragToDismiss() {
    const sheet = document.getElementById('bottom-sheet');
    const overlay = document.getElementById('sheet-overlay');
    const handle = sheet.querySelector('.sheet-handle');
    let startY = 0;
    let currentY = 0;
    let isDragging = false;
    const CLOSE_THRESHOLD = 0.3;

    function onStart(e) {
        isDragging = true;
        startY = e.type === 'touchstart' ? e.touches[0].clientY : e.clientY;
        sheet.classList.add('dragging');
        sheet.classList.remove('closing');
    }

    function onMove(e) {
        if (!isDragging) return;
        
        const clientY = e.type === 'touchmove' ? e.touches[0].clientY : e.clientY;
        currentY = clientY - startY;
        
        // Solo permitir arrastre hacia abajo
        if (currentY > 0) {
            e.preventDefault();
            sheet.style.transform = `translateX(-50%) translateY(${currentY}px)`;
            
            // Feedback visual: opacidad del overlay
            const overlay = document.getElementById('sheet-overlay');
            const opacity = Math.max(0, 1 - (currentY / 300));
            overlay.style.opacity = opacity;
        }
    }

    function onEnd() {
    if (!isDragging) return;
    isDragging = false;
    sheet.classList.remove('dragging');
    
    const sheetHeight = sheet.offsetHeight;
    const dragPercentage = currentY / sheetHeight;
    
    if (dragPercentage > CLOSE_THRESHOLD) {
        // Cerrar: animar hacia abajo
        sheet.classList.add('closing');
        sheet.style.transform = `translateX(-50%) translateY(100%)`;
        overlay.style.opacity = '0';
        
        setTimeout(() => {
            closeSheet(); // closeSheet ahora limpia todo
        }, 250);
    } else {
        // Volver a la posición original
        sheet.style.transform = '';
        overlay.style.opacity = '';
    }
    
    currentY = 0;
}

    // Touch events (móvil)
    handle.addEventListener('touchstart', onStart, { passive: true });
    document.addEventListener('touchmove', onMove, { passive: false });
    document.addEventListener('touchend', onEnd);

    // Mouse events (desktop)
    handle.addEventListener('mousedown', onStart);
    document.addEventListener('mousemove', onMove);
    document.addEventListener('mouseup', onEnd);
})();

// Manejo global de errores
window.addEventListener('error', (e) => {
    console.error('Error no capturado:', e.error);
    showToast('Ocurrió un error inesperado');
});

window.addEventListener('unhandledrejection', (e) => {
    console.error('Promise rechazada:', e.reason);
    showToast('Error de conexión');
});

// =========================================
// INITIALIZATION
// =========================================
document.addEventListener('DOMContentLoaded', () => {
    generateSeedActivity();
    
    subscribe(renderMetrics);
    subscribe(renderDashboardFleet);
    subscribe(renderDashboardAlerts);
    subscribe(renderDashboardUpcoming);
    subscribe(renderUpcomingFull);
    subscribe(renderDashboardActivity);
    subscribe(renderFleetFull);
    subscribe(renderAlertsFull);
    subscribe(renderActivityFull);
    subscribe(renderAlertBadges);
    subscribe(renderAvatar);
    subscribe(renderCurrentPlan);
    
    notify();
    lucide.createIcons();
    
    if (State.preferences.darkMode) { 
        document.body.classList.add('dark-mode'); 
        document.getElementById('toggle-dark-mode').checked = true; 
    }
});